from itertools import chain
from glob import glob

def main():
	f=open(testtest, 'r')
	with open('test', 'w') as out:
		for line in lines:
			 line.lThere is NO WARRANTY, to the extent permitted by law.  Type "show copying"
and "show warranty" for details.
This GDB was configured as "x86_64-unknown-linux-gnu".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<http://www.gnu.org/software/gdb/bugs/>.
Find the GDB manual and other documentation resources online at:
<http://www.gnu.org/software/gdb/documentation/>.
For help, type "help".
Type "apropos word" to search for commands related to "word"...
Reading symbols from untitled...done.
(gdb) ~ower()
		out.writelines(sorted(lines))

if __name__ == '__main__':
	main()

